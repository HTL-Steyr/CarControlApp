package htl.steyr.androidcarcontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;
import java.net.Socket;

import htl.steyr.androidcarcontrol.socket.CarSocketConnection;
import htl.steyr.androidcarcontrol.socket.ICarControlSubscriber;
import htl.steyr.androidcarcontrol.socket.ICarMessage;

public class MainActivity extends AppCompatActivity implements ICarControlSubscriber {

    Thread myThread = null;
    CarSocketConnection carSocket = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myThread = new Thread() {
            @Override
            public void run() {
                carSocket = new CarSocketConnection("192.168.43.167", 2109);

                ICarControlSubscriber sub = new ICarControlSubscriber() {
                    @Override
                    public void messageReceived(ICarMessage msg) {
                        System.out.println(msg.getMessage());
                    }
                };

                carSocket.addSubscriber(sub);
            }
        };

        myThread.start();

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String command = "";
                switch (v.getId()) {
                    case R.id.forwardButton:
                        command = "forward";
                        break;
                    case R.id.backwardButton:
                        command = "backward";
                        break;
                    case R.id.leftButton:
                        command = "left";
                        break;
                    case R.id.rightButton:
                        command = "right";
                        break;
                }

                //System.out.println(command);
                carSocket.sendMessage(command);
            }
        };

        Button btn = findViewById(R.id.rightButton);
        btn.setOnClickListener(listener);
        btn = findViewById(R.id.leftButton);
        btn.setOnClickListener(listener);
        btn = findViewById(R.id.forwardButton);
        btn.setOnClickListener(listener);
        btn = findViewById(R.id.backwardButton);
        btn.setOnClickListener(listener);
    }

    @Override
    public void messageReceived(ICarMessage msg) {
        System.out.println(msg.getMessage());
    }
}